"""
Command-line Interface for PDF RAG Application

This module implements a command-line interface for the PDF RAG application,
allowing users to interact with the system through a simple text-based interface.
"""

import os
import argparse
import sys
from typing import List, Dict, Any
from dotenv import load_dotenv

from pdf_processor import PDFProcessor
from lightweight_vector_store import LightweightVectorStore
from rag_query_system import RAGQuerySystem
from answer_verification import AnswerVerificationSystem
from additional_features import AdditionalFeatures

# Load environment variables
load_dotenv()

class CommandLineInterface:
    """Command-line interface for the PDF RAG application."""
    
    def __init__(self):
        """Initialize the command-line interface."""
        self.pdf_processor = PDFProcessor()
        self.vector_store = LightweightVectorStore()
        self.rag_system = RAGQuerySystem(self.vector_store)
        self.verifier = AnswerVerificationSystem(self.rag_system)
        self.features = AdditionalFeatures(self.rag_system)
    
    def run(self):
        """Run the command-line interface."""
        parser = argparse.ArgumentParser(description='PDF RAG Application')
        subparsers = parser.add_subparsers(dest='command', help='Command to run')
        
        # List PDFs command
        list_parser = subparsers.add_parser('list', help='List available PDF documents')
        
        # Query command
        query_parser = subparsers.add_parser('query', help='Query the RAG system')
        query_parser.add_argument('question', type=str, help='Question to ask')
        query_parser.add_argument('--k', type=int, default=4, help='Number of chunks to retrieve')
        
        # Verify command
        verify_parser = subparsers.add_parser('verify', help='Verify an answer')
        verify_parser.add_argument('question', type=str, help='Question being answered')
        verify_parser.add_argument('answer', type=str, help='Answer to verify')
        verify_parser.add_argument('--k', type=int, default=4, help='Number of chunks to retrieve')
        
        # Verify Yes/No command
        verify_yn_parser = subparsers.add_parser('verify-yn', help='Verify a yes/no answer')
        verify_yn_parser.add_argument('question', type=str, help='Yes/no question being answered')
        verify_yn_parser.add_argument('answer', type=str, choices=['yes', 'no'], help='Yes/no answer to verify')
        verify_yn_parser.add_argument('--k', type=int, default=4, help='Number of chunks to retrieve')
        
        # Summarize command
        summarize_parser = subparsers.add_parser('summarize', help='Summarize documents')
        summarize_parser.add_argument('--document', type=str, help='Document to summarize (all if not specified)')
        
        # Metadata command
        metadata_parser = subparsers.add_parser('metadata', help='Explore document metadata')
        
        # Interactive mode command
        interactive_parser = subparsers.add_parser('interactive', help='Start interactive mode')
        
        # Parse arguments
        args = parser.parse_args()
        
        # Execute command
        if args.command == 'list':
            self._list_pdfs()
        elif args.command == 'query':
            self._query(args.question, args.k)
        elif args.command == 'verify':
            self._verify(args.question, args.answer, args.k)
        elif args.command == 'verify-yn':
            self._verify_yes_no(args.question, args.answer, args.k)
        elif args.command == 'summarize':
            self._summarize(args.document)
        elif args.command == 'metadata':
            self._metadata()
        elif args.command == 'interactive':
            self._interactive()
        else:
            parser.print_help()
    
    def _list_pdfs(self):
        """List available PDF documents."""
        pdf_files = self.pdf_processor.list_pdf_files()
        
        if not pdf_files:
            print("No PDF documents found.")
            return
        
        print(f"Found {len(pdf_files)} PDF documents:")
        for i, pdf_file in enumerate(pdf_files, 1):
            print(f"{i}. {os.path.basename(pdf_file)}")
    
    def _query(self, question: str, k: int):
        """Query the RAG system."""
        result = self.features.answer_question(question, k=k)
        
        print("\n" + "="*50)
        print(result["answer"])
        print("="*50)
    
    def _verify(self, question: str, answer: str, k: int):
        """Verify an answer."""
        result = self.verifier.verify_answer(question, answer, k=k)
        
        print("\n" + "="*50)
        print(f"Question: {question}")
        print(f"Answer: {answer}")
        print(f"Verified: {result['verified']}")
        print(f"Confidence: {result['confidence']:.1%}")
        print(f"Explanation: {result['explanation']}")
        
        if result["evidence"]:
            print("\nEvidence:")
            for i, evidence in enumerate(result["evidence"], 1):
                print(f"{i}. {evidence['source']} (Page {evidence['page']})")
                print(f"   {evidence['text'][:100]}...")
        
        print("="*50)
    
    def _verify_yes_no(self, question: str, answer: str, k: int):
        """Verify a yes/no answer with detailed analysis."""
        # First, check the opposite answer to provide a comparison
        opposite_answer = "no" if answer.lower() == "yes" else "yes"
        
        # Verify the user's answer
        result = self.verifier.verify_answer(question, answer, k=k)
        
        # Verify the opposite answer
        opposite_result = self.verifier.verify_answer(question, opposite_answer, k=k)
        
        print("\n" + "="*50)
        print(f"Question: {question}")
        print(f"Your answer: {answer}")
        
        # Display verification status
        if result["verified"]:
            print(f"✓ VERIFIED with {result['confidence']:.1%} confidence")
        else:
            print(f"✗ NOT VERIFIED ({result['confidence']:.1%} confidence)")
        
        print(f"\nExplanation: {result['explanation']}")
        
        # Compare with opposite answer
        print(f"\nComparing with opposite answer ({opposite_answer}):")
        if opposite_result["verified"]:
            print(f"The '{opposite_answer}' answer is verified with {opposite_result['confidence']:.1%} confidence.")
        else:
            print(f"The '{opposite_answer}' answer is not verified ({opposite_result['confidence']:.1%} confidence).")
        
        # Display evidence
        if result["evidence"]:
            print("\nTop evidence for your answer:")
            for i, evidence in enumerate(result["evidence"][:3], 1):
                support_status = "Supports" if evidence["supports"] else "Contradicts"
                print(f"{i}. {evidence['source']} (Page {evidence['page']}) - {support_status} ({evidence['relevance']:.2f} relevance)")
                print(f"   {evidence['text'][:150]}...")
        
        print("="*50)
    
    def _summarize(self, document: str = None):
        """Summarize documents."""
        result = self.features.summarize_document(document)
        
        print("\n" + "="*50)
        print(result["summary"])
        print("="*50)
    
    def _metadata(self):
        """Explore document metadata."""
        result = self.features.explore_document_metadata()
        
        print("\n" + "="*50)
        print(result["analysis"])
        print("="*50)
    
    def _interactive(self):
        """Start interactive mode."""
        print("\nPDF RAG Application - Interactive Mode")
        print("Type 'help' for a list of commands, 'exit' to quit.")
        
        while True:
            try:
                command = input("\n> ").strip()
                
                if command.lower() == 'exit':
                    break
                elif command.lower() == 'help':
                    self._print_help()
                elif command.lower() == 'list':
                    self._list_pdfs()
                elif command.lower().startswith('query '):
                    question = command[6:].strip()
                    self._query(question, 4)
                elif command.lower().startswith('verify '):
                    parts = command[7:].strip().split('|')
                    if len(parts) != 2:
                        print("Usage: verify <question>|<answer>")
                    else:
                        question, answer = parts
                        self._verify(question.strip(), answer.strip(), 4)
                elif command.lower().startswith('verify-yn '):
                    parts = command[10:].strip().split('|')
                    if len(parts) != 2:
                        print("Usage: verify-yn <question>|<yes/no>")
                    else:
                        question, answer = parts
                        answer = answer.strip().lower()
                        if answer not in ['yes', 'no']:
                            print("Answer must be 'yes' or 'no'")
                        else:
                            self._verify_yes_no(question.strip(), answer, 4)
                elif command.lower() == 'summarize':
                    self._summarize()
                elif command.lower().startswith('summarize '):
                    document = command[10:].strip()
                    self._summarize(document)
                elif command.lower() == 'metadata':
                    self._metadata()
                else:
                    print("Unknown command. Type 'help' for a list of commands.")
            
            except KeyboardInterrupt:
                print("\nExiting interactive mode...")
                break
            except Exception as e:
                print(f"Error: {e}")
    
    def _print_help(self):
        """Print help information for interactive mode."""
        print("\nAvailable commands:")
        print("  help                  - Show this help message")
        print("  list                  - List available PDF documents")
        print("  query <question>      - Query the RAG system")
        print("  verify <q>|<a>        - Verify an answer (separate question and answer with |)")
        print("  verify-yn <q>|<y/n>   - Verify a yes/no answer with detailed analysis")
        print("  summarize             - Summarize all documents")
        print("  summarize <document>  - Summarize a specific document")
        print("  metadata              - Explore document metadata")
        print("  exit                  - Exit interactive mode")


def main():
    """Main entry point for the command-line interface."""
    cli = CommandLineInterface()
    cli.run()


if __name__ == "__main__":
    main()
