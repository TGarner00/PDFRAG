"""
Test script for the updated yes/no answer verification system
"""

from answer_verification import AnswerVerificationSystem
from pdf_processor import PDFProcessor
from lightweight_vector_store import LightweightVectorStore
from rag_query_system import RAGQuerySystem

def test_verification_with_sample_pdf():
    """Test the verification system with the sample PDF."""
    # Initialize components
    processor = PDFProcessor()
    vector_store = LightweightVectorStore()
    rag_system = RAGQuerySystem(vector_store)
    verifier = AnswerVerificationSystem(rag_system)
    
    # Process sample PDF if needed
    pdf_files = processor.list_pdf_files()
    if pdf_files:
        print(f"Found {len(pdf_files)} PDF files: {[os.path.basename(f) for f in pdf_files]}")
    else:
        print("No PDF files found. Please ensure sample.pdf is in the data directory.")
        return
    
    # Test questions with expected yes/no answers
    test_cases = [
        {
            "question": "Does RAG enhance language models with external knowledge?",
            "expected_answer": "yes",
            "explanation": "The sample PDF explicitly states that RAG enhances LLMs with external knowledge."
        },
        {
            "question": "Is RAG a type of computer virus?",
            "expected_answer": "no",
            "explanation": "The sample PDF describes RAG as a technique for enhancing LLMs, not a virus."
        },
        {
            "question": "Does RAG stand for Retrieval Augmented Generation?",
            "expected_answer": "yes",
            "explanation": "The sample PDF explicitly defines RAG as Retrieval Augmented Generation."
        },
        {
            "question": "Is chunking strategy irrelevant in RAG systems?",
            "expected_answer": "no",
            "explanation": "The sample PDF mentions that chunking strategy affects retrieval precision."
        }
    ]
    
    # Run tests
    for i, test_case in enumerate(test_cases, 1):
        question = test_case["question"]
        expected = test_case["expected_answer"]
        explanation = test_case["explanation"]
        
        print(f"\n=== Test Case {i}: {question} ===")
        print(f"Expected answer: {expected}")
        print(f"Explanation: {explanation}")
        
        # Test with expected answer
        result = verifier.verify_answer(question, expected)
        print(f"\nVerification for '{expected}' answer:")
        print(f"Verified: {result['verified']}")
        print(f"Confidence: {result['confidence']:.1%}")
        print(f"Explanation: {result['explanation']}")
        
        # Test with opposite answer
        opposite = "no" if expected == "yes" else "yes"
        result_opposite = verifier.verify_answer(question, opposite)
        print(f"\nVerification for '{opposite}' answer (should be rejected):")
        print(f"Verified: {result_opposite['verified']}")
        print(f"Confidence: {result_opposite['confidence']:.1%}")
        print(f"Explanation: {result_opposite['explanation']}")
        
        # Print top evidence
        if result["evidence"]:
            print("\nTop evidence:")
            for j, evidence in enumerate(result["evidence"][:2], 1):
                print(f"Evidence {j} (Relevance: {evidence['relevance']:.2f}, " +
                      f"Supports: {evidence['supports']}, Contradicts: {evidence['contradicts']}):")
                print(f"  {evidence['text'][:200]}...")

if __name__ == "__main__":
    import os
    test_verification_with_sample_pdf()
