"""
Additional Features Module for PDF RAG Application

This module implements additional features for the PDF RAG application,
including document summarization and enhanced question-answering capabilities.
"""

import os
from typing import List, Dict, Any, Tuple
import re
from collections import Counter
from dotenv import load_dotenv

from lightweight_vector_store import LightweightVectorStore
from pdf_processor import PDFProcessor
from rag_query_system import RAGQuerySystem

# Load environment variables
load_dotenv()

class AdditionalFeatures:
    """
    Additional features for the PDF RAG application, including document summarization
    and enhanced question-answering capabilities.
    """
    
    def __init__(self, rag_system=None):
        """
        Initialize the additional features module.
        
        Args:
            rag_system: RAG system for document retrieval (created if None)
        """
        # Initialize RAG system
        self.rag_system = rag_system or RAGQuerySystem()
        self.pdf_processor = PDFProcessor()
    
    def summarize_document(self, document_name: str = None) -> Dict[str, Any]:
        """
        Generate a summary of a specific document or all documents.
        
        Args:
            document_name: Name of the document to summarize (all if None)
            
        Returns:
            Dictionary containing the summary and source information
        """
        # Get all document chunks
        all_chunks = self.pdf_processor.process_all_documents()
        
        if not all_chunks:
            return {
                "summary": "No documents found to summarize.",
                "sources": []
            }
        
        # Filter chunks by document name if specified
        if document_name:
            chunks = [chunk for chunk in all_chunks if chunk.metadata.get("source") == document_name]
            if not chunks:
                return {
                    "summary": f"Document '{document_name}' not found.",
                    "sources": []
                }
        else:
            chunks = all_chunks
        
        # Group chunks by document
        documents = {}
        for chunk in chunks:
            source = chunk.metadata.get("source", "Unknown")
            if source not in documents:
                documents[source] = []
            documents[source].append(chunk)
        
        # Generate summary for each document
        summaries = []
        sources = []
        
        for source, doc_chunks in documents.items():
            # Sort chunks by page number
            doc_chunks.sort(key=lambda x: x.metadata.get("page", 0))
            
            # Extract key sentences and terms
            doc_summary = self._extract_key_sentences(doc_chunks)
            
            summaries.append({
                "document": source,
                "summary": doc_summary,
                "pages": len(set(chunk.metadata.get("page", 0) for chunk in doc_chunks))
            })
            
            sources.append({
                "file": source,
                "pages": len(set(chunk.metadata.get("page", 0) for chunk in doc_chunks))
            })
        
        # Combine summaries
        if len(summaries) == 1:
            combined_summary = f"Summary of {summaries[0]['document']} ({summaries[0]['pages']} pages):\n\n{summaries[0]['summary']}"
        else:
            combined_summary = "Summary of all documents:\n\n"
            for summary in summaries:
                combined_summary += f"--- {summary['document']} ({summary['pages']} pages) ---\n{summary['summary']}\n\n"
        
        return {
            "summary": combined_summary,
            "sources": sources
        }
    
    def _extract_key_sentences(self, chunks: List[Dict[str, Any]]) -> str:
        """
        Extract key sentences from document chunks to create a summary.
        
        Args:
            chunks: Document chunks to summarize
            
        Returns:
            Summary text
        """
        # Combine all text
        full_text = " ".join([chunk.page_content for chunk in chunks])
        
        # Split into sentences
        sentences = re.split(r'(?<=[.!?])\s+', full_text)
        
        # Remove duplicate sentences
        unique_sentences = []
        seen_sentences = set()
        for sentence in sentences:
            normalized = re.sub(r'\s+', ' ', sentence.lower().strip())
            if normalized not in seen_sentences and len(normalized) > 20:
                unique_sentences.append(sentence)
                seen_sentences.add(normalized)
        
        # Extract key terms
        words = re.findall(r'\b\w+\b', full_text.lower())
        word_freq = Counter(words)
        
        # Remove common stop words
        stop_words = {'a', 'an', 'the', 'and', 'or', 'but', 'is', 'are', 'was', 'were', 
                     'in', 'on', 'at', 'to', 'for', 'with', 'by', 'about', 'as', 'of',
                     'that', 'this', 'these', 'those', 'it', 'they', 'them', 'their',
                     'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'should',
                     'can', 'could', 'may', 'might', 'must', 'be', 'been', 'being'}
        
        for word in stop_words:
            if word in word_freq:
                del word_freq[word]
        
        # Score sentences based on key terms
        sentence_scores = []
        for sentence in unique_sentences:
            words_in_sentence = re.findall(r'\b\w+\b', sentence.lower())
            score = sum(word_freq.get(word, 0) for word in words_in_sentence) / len(words_in_sentence) if words_in_sentence else 0
            sentence_scores.append((sentence, score))
        
        # Sort sentences by score
        sentence_scores.sort(key=lambda x: x[1], reverse=True)
        
        # Select top sentences (up to 5 or 20% of sentences, whichever is smaller)
        num_sentences = min(5, max(1, len(sentence_scores) // 5))
        top_sentences = [sentence for sentence, _ in sentence_scores[:num_sentences]]
        
        # Sort sentences by their original order
        original_order = []
        for sentence in top_sentences:
            for i, (s, _) in enumerate(sentence_scores):
                if s == sentence:
                    original_order.append((sentence, i))
                    break
        
        original_order.sort(key=lambda x: x[1])
        ordered_sentences = [sentence for sentence, _ in original_order]
        
        # Combine sentences into a summary
        summary = " ".join(ordered_sentences)
        
        return summary
    
    def answer_question(self, question: str, k: int = 4) -> Dict[str, Any]:
        """
        Enhanced question answering with more detailed responses.
        
        Args:
            question: User question
            k: Number of chunks to retrieve
            
        Returns:
            Dictionary containing the answer and source information
        """
        # Use the RAG system to generate a response
        result = self.rag_system.generate_response(question, k=k)
        
        # Enhance the response with additional context and formatting
        enhanced_answer = self._enhance_answer(question, result["answer"], result["source_chunks"])
        
        return {
            "answer": enhanced_answer,
            "sources": result["sources"],
            "source_chunks": result["source_chunks"]
        }
    
    def _enhance_answer(self, question: str, answer: str, chunks: List[Dict[str, Any]]) -> str:
        """
        Enhance an answer with additional context and better formatting.
        
        Args:
            question: User question
            answer: Original answer
            chunks: Source document chunks
            
        Returns:
            Enhanced answer
        """
        # Add a header
        enhanced = f"Answer to: {question}\n\n"
        
        # Add the main answer
        enhanced += answer
        
        # Add source citations
        if chunks:
            enhanced += "\n\nSources:\n"
            for i, chunk in enumerate(chunks[:3], 1):
                source = chunk.metadata.get("source", "Unknown")
                page = chunk.metadata.get("page", 1)
                enhanced += f"{i}. {source} (Page {page})\n"
        
        return enhanced
    
    def explore_document_metadata(self) -> Dict[str, Any]:
        """
        Explore and analyze document metadata.
        
        Returns:
            Dictionary containing metadata analysis
        """
        # Get all document chunks
        all_chunks = self.pdf_processor.process_all_documents()
        
        if not all_chunks:
            return {
                "analysis": "No documents found to analyze.",
                "documents": []
            }
        
        # Extract and analyze metadata
        documents = {}
        for chunk in all_chunks:
            source = chunk.metadata.get("source", "Unknown")
            if source not in documents:
                documents[source] = {
                    "pages": set(),
                    "metadata": {}
                }
            
            # Add page to set
            page = chunk.metadata.get("page", 0)
            documents[source]["pages"].add(page)
            
            # Add other metadata
            for key, value in chunk.metadata.items():
                if key not in ["source", "page", "page_label"]:
                    documents[source]["metadata"][key] = value
        
        # Format the analysis
        analysis = "Document Metadata Analysis:\n\n"
        doc_info = []
        
        for source, info in documents.items():
            analysis += f"Document: {source}\n"
            analysis += f"Pages: {len(info['pages'])}\n"
            analysis += "Metadata:\n"
            
            for key, value in info["metadata"].items():
                analysis += f"  - {key}: {value}\n"
            
            analysis += "\n"
            
            doc_info.append({
                "file": source,
                "pages": len(info["pages"]),
                "metadata": info["metadata"]
            })
        
        return {
            "analysis": analysis,
            "documents": doc_info
        }


if __name__ == "__main__":
    # Example usage
    features = AdditionalFeatures()
    
    # Test document summarization
    summary_result = features.summarize_document()
    print("=== Document Summary ===")
    print(summary_result["summary"])
    
    # Test enhanced question answering
    qa_result = features.answer_question("What is RAG?")
    print("\n=== Enhanced Question Answering ===")
    print(qa_result["answer"])
    
    # Test metadata exploration
    metadata_result = features.explore_document_metadata()
    print("\n=== Document Metadata Analysis ===")
    print(metadata_result["analysis"])
