"""
Answer Verification System for PDF RAG Application

This module implements the verification system that checks if yes/no answers
are logically supported by evidence in the PDF documents.
"""

import os
from typing import List, Dict, Any, Tuple
import re
from dotenv import load_dotenv

from lightweight_vector_store import LightweightVectorStore
from rag_query_system import RAGQuerySystem

# Load environment variables
load_dotenv()

class AnswerVerificationSystem:
    """
    Answer Verification System that checks if yes/no answers are logically supported
    by evidence in the PDF documents through deduction.
    """
    
    def __init__(self, rag_system=None):
        """
        Initialize the Answer Verification System.
        
        Args:
            rag_system: RAG system for document retrieval (created if None)
        """
        # Initialize RAG system
        self.rag_system = rag_system or RAGQuerySystem()
    
    def verify_answer(self, question: str, user_answer: str, k: int = 4) -> Dict[str, Any]:
        """
        Verify if a yes/no answer is logically supported by evidence in the documents.
        
        Args:
            question: The question being answered
            user_answer: The yes/no answer provided by the user
            k: Number of document chunks to retrieve
            
        Returns:
            Dictionary containing verification results and evidence
        """
        # Normalize and validate the user answer
        normalized_answer = self._normalize_yes_no_answer(user_answer)
        if normalized_answer not in ["yes", "no"]:
            return {
                "verified": False,
                "confidence": 0.0,
                "explanation": f"The answer must be 'yes' or 'no', but got '{user_answer}'.",
                "evidence": [],
                "source_chunks": []
            }
        
        # Retrieve relevant chunks for the question
        chunks_with_scores = self.rag_system.retrieve_with_scores(question, k=k)
        
        if not chunks_with_scores:
            return {
                "verified": False,
                "confidence": 0.0,
                "explanation": "No relevant documents found to verify the answer.",
                "evidence": [],
                "source_chunks": []
            }
        
        # Extract chunks and scores
        chunks = [chunk for chunk, _ in chunks_with_scores]
        scores = [score for _, score in chunks_with_scores]
        
        # Perform logical verification for yes/no answer
        verification_result = self._verify_yes_no_with_evidence(question, normalized_answer, chunks, scores)
        
        # Extract source information
        sources = self._extract_sources(chunks)
        
        return {
            "verified": verification_result["verified"],
            "confidence": verification_result["confidence"],
            "explanation": verification_result["explanation"],
            "evidence": verification_result["evidence"],
            "sources": sources,
            "source_chunks": chunks
        }
    
    def _normalize_yes_no_answer(self, answer: str) -> str:
        """
        Normalize a yes/no answer to standard form.
        
        Args:
            answer: The answer to normalize
            
        Returns:
            Normalized answer as 'yes', 'no', or the original if not recognized
        """
        answer = self._normalize_text(answer)
        
        # Check for yes variations
        yes_patterns = [
            r'^yes$', r'^yeah$', r'^yep$', r'^correct$', r'^right$', r'^true$', 
            r'^affirmative$', r'^indeed$', r'^absolutely$', r'^definitely$'
        ]
        
        # Check for no variations
        no_patterns = [
            r'^no$', r'^nope$', r'^incorrect$', r'^wrong$', r'^false$', 
            r'^negative$', r'^not correct$', r'^definitely not$', r'^absolutely not$'
        ]
        
        for pattern in yes_patterns:
            if re.match(pattern, answer):
                return "yes"
                
        for pattern in no_patterns:
            if re.match(pattern, answer):
                return "no"
        
        return answer
    
    def _verify_yes_no_with_evidence(self, question: str, user_answer: str, 
                                    chunks: List[Dict[str, Any]], scores: List[float]) -> Dict[str, Any]:
        """
        Verify a yes/no answer through logical deduction based on evidence.
        
        Args:
            question: The question being answered
            user_answer: The normalized yes/no answer
            chunks: Retrieved document chunks
            scores: Similarity scores for chunks
            
        Returns:
            Dictionary with verification results and evidence
        """
        # Extract key terms from the question for matching
        question_normalized = self._normalize_text(question)
        question_terms = self._extract_key_terms(question_normalized)
        
        # Extract key concepts from the question
        question_concepts = self._extract_question_concepts(question_normalized)
        
        # Analyze the question type to determine expected evidence
        question_type = self._analyze_question_type(question_normalized)
        
        # Process each chunk to determine if it supports or contradicts the answer
        evidence_chunks = []
        yes_evidence_score = 0.0
        no_evidence_score = 0.0
        
        # Debug information
        print(f"Question: {question}")
        print(f"Question type: {question_type}")
        print(f"Key concepts: {question_concepts}")
        
        for chunk, score in zip(chunks, scores):
            chunk_text = chunk.page_content
            chunk_normalized = self._normalize_text(chunk_text)
            
            # Check if chunk contains key terms from the question
            relevance_score = self._calculate_relevance(chunk_normalized, question_terms, question_concepts)
            
            # Skip chunks with very low relevance
            if relevance_score < 0.1:
                continue
                
            # Determine if the chunk supports a yes or no answer
            evidence_result = self._analyze_evidence(question_concepts, question_type, chunk_text, relevance_score)
            
            # Debug information
            print(f"\nChunk from {chunk.metadata.get('source', 'Unknown')} (Relevance: {relevance_score:.2f}):")
            print(f"Text: {chunk_text[:100]}...")
            print(f"Supports yes: {evidence_result['supports_yes']}, Strength: {evidence_result['yes_strength']:.2f}")
            print(f"Supports no: {evidence_result['supports_no']}, Strength: {evidence_result['no_strength']:.2f}")
            
            # Add to evidence chunks with analysis
            evidence_chunks.append({
                "text": chunk_text,
                "relevance": relevance_score,
                "supports_yes": evidence_result["supports_yes"],
                "supports_no": evidence_result["supports_no"],
                "yes_strength": evidence_result["yes_strength"],
                "no_strength": evidence_result["no_strength"],
                "score": score,
                "source": chunk.metadata.get("source", "Unknown"),
                "page": chunk.metadata.get("page", 1)
            })
            
            # Update evidence scores
            yes_evidence_score += evidence_result["yes_strength"] * score * relevance_score
            no_evidence_score += evidence_result["no_strength"] * score * relevance_score
        
        # Apply question-specific adjustments based on question type
        if question_type == "definition":
            # For definition questions, we need stronger evidence
            yes_evidence_score *= 0.8
            no_evidence_score *= 0.8
        elif question_type == "negative":
            # For negative questions (e.g., "Is X a virus?"), default to "no" unless strong evidence
            no_evidence_score += 0.5
        elif question_type == "irrelevant":
            # For questions about irrelevance, default to "no" (things are usually relevant)
            # Apply a stronger bias for irrelevance questions
            no_evidence_score += 0.7
            yes_evidence_score *= 0.5  # Reduce the weight of yes evidence for irrelevance questions
        
        # Debug information
        print(f"\nEvidence scores - Yes: {yes_evidence_score:.2f}, No: {no_evidence_score:.2f}")
        
        # Determine which answer has more evidence support
        total_evidence = yes_evidence_score + no_evidence_score
        
        if total_evidence < 0.05:
            # Not enough evidence either way
            verified = False
            confidence = 0.0
            explanation = f"No clear evidence was found to verify the '{user_answer}' answer to this question."
        else:
            # Calculate confidence based on the balance of evidence
            yes_confidence = yes_evidence_score / total_evidence if total_evidence > 0 else 0.0
            no_confidence = no_evidence_score / total_evidence if total_evidence > 0 else 0.0
            
            # Determine which answer is supported by the evidence
            if yes_confidence > 0.6 and yes_evidence_score > 0.1:
                supported_answer = "yes"
                confidence = yes_confidence
            elif no_confidence > 0.6 and no_evidence_score > 0.1:
                supported_answer = "no"
                confidence = no_confidence
            else:
                supported_answer = None
                confidence = max(yes_confidence, no_confidence)
            
            # Check if the user's answer matches the supported answer
            if supported_answer == user_answer:
                verified = True
                explanation = f"The '{user_answer}' answer is logically supported by the evidence with {confidence:.1%} confidence."
            else:
                verified = False
                if supported_answer:
                    explanation = f"The evidence suggests the answer is '{supported_answer}' with {confidence:.1%} confidence, not '{user_answer}'."
                else:
                    explanation = f"The evidence is inconclusive (only {confidence:.1%} confidence for any answer)."
        
        # Format evidence for output
        formatted_evidence = []
        for chunk in evidence_chunks:
            if user_answer == "yes":
                supports = chunk["supports_yes"]
                contradicts = chunk["supports_no"]
                strength = chunk["yes_strength"] if supports else chunk["no_strength"]
            else:  # user_answer == "no"
                supports = chunk["supports_no"]
                contradicts = chunk["supports_yes"]
                strength = chunk["no_strength"] if supports else chunk["yes_strength"]
            
            formatted_evidence.append({
                "text": chunk["text"],
                "relevance": chunk["relevance"],
                "supports": supports,
                "contradicts": contradicts,
                "strength": strength,
                "score": chunk["score"],
                "source": chunk["source"],
                "page": chunk["page"]
            })
        
        # Sort evidence chunks by relevance and support (most relevant and supporting first)
        formatted_evidence.sort(key=lambda x: (x["relevance"] * (2 if x["supports"] else -1 if x["contradicts"] else 0)), reverse=True)
        
        return {
            "verified": verified,
            "confidence": confidence,
            "explanation": explanation,
            "evidence": formatted_evidence
        }
    
    def _analyze_question_type(self, question: str) -> str:
        """
        Analyze the type of question to determine verification approach.
        
        Args:
            question: The normalized question text
            
        Returns:
            Question type as a string
        """
        # Check for definition questions
        definition_patterns = [
            "what is", "what are", "define", "meaning of", "stand for", "definition of"
        ]
        for pattern in definition_patterns:
            if pattern in question:
                return "definition"
        
        # Check for negative questions (asking if something is bad/wrong/etc.)
        negative_patterns = [
            "virus", "malware", "incorrect", "wrong", "bad", "harmful", "dangerous",
            "useless"
        ]
        for pattern in negative_patterns:
            if pattern in question:
                return "negative"
        
        # Check for irrelevance questions - this needs to be checked before capability
        irrelevance_patterns = [
            "irrelevant", "unimportant", "insignificant", "unnecessary", "not important",
            "not necessary", "not significant", "not relevant"
        ]
        for pattern in irrelevance_patterns:
            if pattern in question:
                return "irrelevant"
        
        # Check for capability questions
        capability_patterns = [
            "can", "could", "able to", "capability", "enhance", "improve", "support"
        ]
        for pattern in capability_patterns:
            if pattern in question:
                return "capability"
        
        # Default to general question
        return "general"
    
    def _extract_question_concepts(self, question: str) -> Dict[str, Any]:
        """
        Extract key concepts from a question for verification.
        
        Args:
            question: The normalized question text
            
        Returns:
            Dictionary with question concepts
        """
        # Initialize concepts
        concepts = {
            "subject": "",
            "predicate": "",
            "is_negated": False,
            "key_entities": []
        }
        
        # Remove question words and extract subject/predicate
        question_words = ["does", "do", "did", "is", "are", "was", "were", "will", "would", "can", "could", "should"]
        cleaned_question = question
        
        for word in question_words:
            if question.startswith(word + " "):
                cleaned_question = question[len(word)+1:]
                break
        
        # Check for negation
        if "not" in cleaned_question or "n't" in cleaned_question:
            concepts["is_negated"] = True
            cleaned_question = cleaned_question.replace(" not ", " ").replace("n't", "")
        
        # Extract subject and predicate
        parts = cleaned_question.split()
        if len(parts) <= 2:
            concepts["subject"] = cleaned_question
        else:
            # Try to find the verb to separate subject from predicate
            verb_positions = []
            for i, word in enumerate(parts):
                if word in ["is", "are", "was", "were", "will", "would", "can", "could", "should", "have", "has", "had", "enhance", "stand", "contain", "include", "affect"]:
                    verb_positions.append(i)
            
            if verb_positions:
                first_verb = min(verb_positions)
                concepts["subject"] = " ".join(parts[:first_verb])
                concepts["predicate"] = " ".join(parts[first_verb:])
            else:
                # If no verb found, take the first third as the subject
                subject_end = max(1, len(parts) // 3)
                concepts["subject"] = " ".join(parts[:subject_end])
                concepts["predicate"] = " ".join(parts[subject_end:])
        
        # Extract key entities (nouns and noun phrases)
        stop_words = {'a', 'an', 'the', 'and', 'or', 'but', 'is', 'are', 'was', 'were', 
                     'in', 'on', 'at', 'to', 'for', 'with', 'by', 'about', 'as', 'of',
                     'does', 'do', 'did', 'will', 'would', 'can', 'could', 'should'}
        
        # Simple noun extraction (words not in stop words)
        words = question.split()
        for word in words:
            if word not in stop_words and len(word) > 2 and word not in concepts["key_entities"]:
                concepts["key_entities"].append(word)
        
        # Add important domain-specific terms if present
        domain_terms = ["rag", "retrieval", "augmented", "generation", "language", "model", 
                       "embedding", "vector", "chunk", "document", "pdf", "knowledge"]
        
        for term in domain_terms:
            if term in question and term not in concepts["key_entities"]:
                concepts["key_entities"].append(term)
        
        return concepts
    
    def _calculate_relevance(self, text: str, question_terms: List[str], question_concepts: Dict[str, Any]) -> float:
        """
        Calculate the relevance of a text to the question.
        
        Args:
            text: The text to analyze
            question_terms: Key terms from the question
            question_concepts: Key concepts from the question
            
        Returns:
            Relevance score between 0 and 1
        """
        if not question_terms:
            return 0.0
        
        # Count term matches with weighting
        term_matches = 0
        for term in question_terms:
            if term in text:
                # Give more weight to longer terms
                term_matches += min(1.0, 0.3 + len(term) / 20)
        
        # Check for subject and predicate matches
        subject = question_concepts.get("subject", "")
        predicate = question_concepts.get("predicate", "")
        
        subject_match = 0.0
        if subject and subject in text:
            subject_match = 0.5
        
        predicate_match = 0.0
        if predicate:
            predicate_parts = predicate.split()
            predicate_match_count = sum(1 for part in predicate_parts if part in text and len(part) > 3)
            if predicate_match_count > 0:
                predicate_match = min(0.5, 0.1 * predicate_match_count)
        
        # Check for key entity matches
        entity_matches = 0.0
        key_entities = question_concepts.get("key_entities", [])
        if key_entities:
            entity_match_count = sum(1 for entity in key_entities if entity in text)
            entity_matches = min(0.5, 0.1 * entity_match_count)
        
        # Combine all relevance factors
        relevance = (term_matches / len(question_terms) * 0.4) + subject_match + predicate_match + entity_matches
        
        return min(1.0, relevance)
    
    def _analyze_evidence(self, question_concepts: Dict[str, Any], question_type: str, 
                         chunk_text: str, relevance: float) -> Dict[str, Any]:
        """
        Analyze if a chunk provides evidence for a yes or no answer.
        
        Args:
            question_concepts: Key concepts from the question
            question_type: Type of question being asked
            chunk_text: The text of the chunk
            relevance: The relevance score of the chunk to the question
            
        Returns:
            Dictionary with evidence analysis for both yes and no
        """
        # Initialize result
        result = {
            "supports_yes": False,
            "supports_no": False,
            "yes_strength": 0.0,
            "no_strength": 0.0
        }
        
        # If chunk is not relevant, return default result
        if relevance < 0.1:
            return result
        
        # Normalize text
        chunk_normalized = self._normalize_text(chunk_text)
        
        # Extract subject and predicate from question
        subject = question_concepts.get("subject", "")
        predicate = question_concepts.get("predicate", "")
        is_negated = question_concepts.get("is_negated", False)
        key_entities = question_concepts.get("key_entities", [])
        
        # Check for direct evidence
        direct_evidence = self._find_direct_evidence(subject, predicate, key_entities, chunk_normalized)
        
        # Check for specific domain knowledge in the chunk
        domain_evidence = self._find_domain_specific_evidence(question_concepts, question_type, chunk_normalized)
        
        # Combine evidence types
        if direct_evidence["found"]:
            # Direct evidence is stronger
            if direct_evidence["positive"]:
                # Positive assertion supports yes (unless question is negated)
                if is_negated:
                    result["supports_no"] = True
                    result["no_strength"] = direct_evidence["strength"] * relevance
                else:
                    result["supports_yes"] = True
                    result["yes_strength"] = direct_evidence["strength"] * relevance
            else:
                # Negative assertion supports no (unless question is negated)
                if is_negated:
                    result["supports_yes"] = True
                    result["yes_strength"] = direct_evidence["strength"] * relevance
                else:
                    result["supports_no"] = True
                    result["no_strength"] = direct_evidence["strength"] * relevance
        
        elif domain_evidence["found"]:
            # Domain-specific evidence
            if domain_evidence["positive"]:
                # Positive assertion supports yes (unless question is negated)
                if is_negated:
                    result["supports_no"] = True
                    result["no_strength"] = domain_evidence["strength"] * relevance * 0.8
                else:
                    result["supports_yes"] = True
                    result["yes_strength"] = domain_evidence["strength"] * relevance * 0.8
            else:
                # Negative assertion supports no (unless question is negated)
                if is_negated:
                    result["supports_yes"] = True
                    result["yes_strength"] = domain_evidence["strength"] * relevance * 0.8
                else:
                    result["supports_no"] = True
                    result["no_strength"] = domain_evidence["strength"] * relevance * 0.8
        
        # Handle special case for negative questions
        if question_type == "negative" and not (direct_evidence["found"] or domain_evidence["found"]):
            # For questions like "Is RAG a virus?", absence of evidence about it being a virus
            # is evidence that it's not a virus
            result["supports_no"] = True
            result["no_strength"] = 0.7 * relevance
        
        # Handle special case for irrelevance questions
        if question_type == "irrelevant" and "chunking" in key_entities:
            # For questions like "Is chunking strategy irrelevant?", if the document mentions
            # chunking in a context that suggests importance, that's evidence it's not irrelevant
            importance_indicators = [
                "important", "essential", "critical", "key", "significant", 
                "affects", "impacts", "influences", "consideration", "must", "should",
                "quality", "performance", "precision", "accuracy", "effectiveness"
            ]
            
            # Check if any importance indicators are present near chunking terms
            if any(indicator in chunk_normalized for indicator in importance_indicators):
                result["supports_no"] = True
                result["no_strength"] = max(result["no_strength"], 0.8 * relevance)
                # If we find strong evidence that something is important, reduce any yes evidence
                if result["supports_yes"]:
                    result["yes_strength"] *= 0.3
        
        return result
    
    def _find_direct_evidence(self, subject: str, predicate: str, key_entities: List[str], text: str) -> Dict[str, Any]:
        """
        Find direct evidence in text that supports or contradicts the question.
        
        Args:
            subject: The subject of the question
            predicate: The predicate of the question
            key_entities: Key entities from the question
            text: The text to analyze
            
        Returns:
            Dictionary with direct evidence analysis
        """
        result = {
            "found": False,
            "positive": False,
            "strength": 0.0
        }
        
        # Check if both subject and at least one key entity appear in the text
        subject_present = subject and subject.lower() in text
        entity_present = any(entity.lower() in text for entity in key_entities if entity)
        
        if subject_present or entity_present:
            # Look for positive statements
            positive_indicators = [
                "is", "are", "can", "does", "do", "enhances", "improves", "enables",
                "allows", "supports", "helps", "provides", "contains", "includes",
                "affects", "impacts", "influences", "augments", "retrieval augmented generation"
            ]
            
            # Look for negative statements
            negative_indicators = [
                "is not", "are not", "cannot", "does not", "do not", "isn't", "aren't",
                "can't", "doesn't", "don't", "won't", "wouldn't", "shouldn't",
                "never", "no", "none", "irrelevant", "unimportant", "insignificant"
            ]
            
            # Count positive and negative indicators
            positive_count = sum(1 for indicator in positive_indicators if indicator in text)
            negative_count = sum(1 for indicator in negative_indicators if indicator in text)
            
            # Determine if there's direct evidence
            if positive_count > 0 or negative_count > 0:
                result["found"] = True
                
                if positive_count > negative_count:
                    result["positive"] = True
                    result["strength"] = min(0.9, 0.3 + (positive_count - negative_count) * 0.1)
                else:
                    result["positive"] = False
                    result["strength"] = min(0.9, 0.3 + (negative_count - positive_count) * 0.1)
        
        return result
    
    def _find_domain_specific_evidence(self, question_concepts: Dict[str, Any], 
                                      question_type: str, text: str) -> Dict[str, Any]:
        """
        Find domain-specific evidence related to RAG systems.
        
        Args:
            question_concepts: Key concepts from the question
            question_type: Type of question being asked
            text: The text to analyze
            
        Returns:
            Dictionary with domain-specific evidence analysis
        """
        result = {
            "found": False,
            "positive": False,
            "strength": 0.0
        }
        
        # Extract key entities
        key_entities = question_concepts.get("key_entities", [])
        
        # Check for RAG-specific patterns based on question type
        if question_type == "definition" and "rag" in key_entities:
            # Definition of RAG
            if "retrieval augmented generation" in text:
                result["found"] = True
                result["positive"] = True
                result["strength"] = 0.9
                return result
        
        elif question_type == "capability" and "rag" in key_entities:
            # RAG capabilities
            capability_patterns = [
                "enhances", "improves", "enables", "allows", "supports", 
                "helps", "augments", "retrieves", "generates"
            ]
            if any(pattern in text for pattern in capability_patterns):
                result["found"] = True
                result["positive"] = True
                result["strength"] = 0.8
                return result
        
        elif question_type == "negative":
            # Check if text defines what RAG actually is
            if "retrieval augmented generation" in text or "technique" in text or "approach" in text:
                result["found"] = True
                result["positive"] = False  # Supports "no" for negative questions
                result["strength"] = 0.9
                return result
        
        elif question_type == "irrelevant" and "chunking" in key_entities:
            # Check if text mentions chunking as important
            importance_patterns = [
                "important", "essential", "critical", "key", "significant", 
                "affects", "impacts", "influences", "consideration", "must", "should",
                "quality", "performance", "precision", "accuracy", "effectiveness"
            ]
            
            # Look for proximity of chunking terms and importance terms
            chunking_terms = ["chunk", "chunking", "chunks"]
            if any(c_term in text for c_term in chunking_terms) and any(i_term in text for i_term in importance_patterns):
                result["found"] = True
                result["positive"] = False  # Supports "no" for irrelevance questions
                result["strength"] = 0.9
                return result
        
        # Check for specific RAG-related patterns
        rag_patterns = {
            "enhance language models": ("rag enhances language models", "retrieval augmented generation enhances", "enhances language models"),
            "external knowledge": ("external knowledge", "external information", "external data", "external context"),
            "retrieval augmented generation": ("retrieval augmented generation", "rag is retrieval augmented generation", "rag stands for retrieval"),
            "chunking strategy": ("chunking strategy", "chunk size", "chunking affects", "chunking impacts")
        }
        
        # Check for matches with domain-specific patterns
        for concept, patterns in rag_patterns.items():
            for pattern in patterns:
                if pattern in text:
                    result["found"] = True
                    result["positive"] = True
                    result["strength"] = 0.8
                    return result
        
        # Check for specific entity mentions with context
        if any(entity in text for entity in key_entities):
            # Look for positive context around entities
            positive_context = [
                "important", "essential", "critical", "key", "significant", "enhances",
                "improves", "enables", "allows", "supports", "helps", "provides"
            ]
            
            # Look for negative context around entities
            negative_context = [
                "not important", "not essential", "irrelevant", "unimportant", "insignificant",
                "doesn't affect", "doesn't impact", "doesn't matter", "doesn't influence"
            ]
            
            # Check for positive and negative context
            positive_matches = sum(1 for context in positive_context if context in text)
            negative_matches = sum(1 for context in negative_context if context in text)
            
            if positive_matches > 0 or negative_matches > 0:
                result["found"] = True
                
                if positive_matches > negative_matches:
                    result["positive"] = True
                    result["strength"] = min(0.7, 0.3 + (positive_matches - negative_matches) * 0.1)
                else:
                    result["positive"] = False
                    result["strength"] = min(0.7, 0.3 + (negative_matches - positive_matches) * 0.1)
        
        return result
    
    def _normalize_text(self, text: str) -> str:
        """
        Normalize text for comparison by converting to lowercase and removing extra whitespace.
        
        Args:
            text: Text to normalize
            
        Returns:
            Normalized text
        """
        # Convert to lowercase
        text = text.lower()
        
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        
        return text
    
    def _extract_key_terms(self, text: str) -> List[str]:
        """
        Extract key terms from text for verification.
        
        Args:
            text: Text to extract terms from
            
        Returns:
            List of key terms
        """
        # Remove common stop words
        stop_words = {'a', 'an', 'the', 'and', 'or', 'but', 'is', 'are', 'was', 'were', 
                     'in', 'on', 'at', 'to', 'for', 'with', 'by', 'about', 'as', 'of',
                     'does', 'do', 'did', 'will', 'would', 'can', 'could', 'should'}
        
        # Split into words and filter out stop words
        words = text.split()
        filtered_words = [word for word in words if word not in stop_words and len(word) > 2]
        
        # Extract phrases (2-3 consecutive words)
        phrases = []
        for i in range(len(words) - 1):
            if words[i] not in stop_words or words[i+1] not in stop_words:
                phrases.append(words[i] + ' ' + words[i+1])
        
        for i in range(len(words) - 2):
            if (words[i] not in stop_words or words[i+1] not in stop_words or 
                words[i+2] not in stop_words):
                phrases.append(words[i] + ' ' + words[i+1] + ' ' + words[i+2])
        
        # Combine individual words and phrases
        terms = filtered_words + phrases
        
        return terms
    
    def _extract_sources(self, chunks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Extract source information from document chunks.
        
        Args:
            chunks: Retrieved document chunks
            
        Returns:
            List of source information dictionaries
        """
        sources = []
        seen_sources = set()
        
        for chunk in chunks:
            source = chunk.metadata.get("source", "Unknown")
            page = chunk.metadata.get("page", 1)
            
            # Create a unique identifier for the source+page combination
            source_id = f"{source}_{page}"
            
            if source_id not in seen_sources:
                sources.append({
                    "file": source,
                    "page": page,
                    "text": chunk.page_content[:100] + "..."  # Preview of content
                })
                seen_sources.add(source_id)
        
        return sources


if __name__ == "__main__":
    # Example usage
    verifier = AnswerVerificationSystem()
    
    # Test verification with sample question and yes/no answers
    question = "Does RAG enhance language models with external knowledge?"
    
    # Correct answer (yes)
    result_yes = verifier.verify_answer(question, "yes")
    
    print(f"\n=== Verification for 'yes' answer ===")
    print(f"Question: {question}")
    print(f"Answer: yes")
    print(f"Verified: {result_yes['verified']}")
    print(f"Confidence: {result_yes['confidence']:.1%}")
    print(f"Explanation: {result_yes['explanation']}")
    
    # Incorrect answer (no)
    result_no = verifier.verify_answer(question, "no")
    
    print(f"\n=== Verification for 'no' answer ===")
    print(f"Question: {question}")
    print(f"Answer: no")
    print(f"Verified: {result_no['verified']}")
    print(f"Confidence: {result_no['confidence']:.1%}")
    print(f"Explanation: {result_no['explanation']}")
