"""
RAG Query System for PDF Application

This module implements the Retrieval Augmented Generation (RAG) system
that retrieves relevant document chunks and generates responses to user queries.
"""

import os
from typing import List, Dict, Any, Tuple
from dotenv import load_dotenv

from lightweight_vector_store import LightweightVectorStore
from pdf_processor import PDFProcessor

# Load environment variables
load_dotenv()

class RAGQuerySystem:
    """
    RAG Query System that retrieves relevant document chunks and generates responses.
    Uses a lightweight approach without requiring heavy LLM dependencies.
    """
    
    def __init__(self, vector_store=None):
        """
        Initialize the RAG Query System.
        
        Args:
            vector_store: Vector store for document retrieval (created if None)
        """
        # Initialize vector store
        self.vector_store = vector_store or LightweightVectorStore()
        
        # Check if vector store is populated, if not, populate it
        stats = self.vector_store.get_collection_stats()
        if stats["count"] == 0:
            self._populate_vector_store()
    
    def _populate_vector_store(self):
        """Populate the vector store with document chunks from PDFs."""
        processor = PDFProcessor()
        chunks = processor.process_all_documents()
        if chunks:
            self.vector_store.add_documents(chunks)
            print(f"Vector store populated with {len(chunks)} document chunks")
        else:
            print("No PDF documents found to populate vector store")
    
    def retrieve_relevant_chunks(self, query: str, k: int = 4) -> List[Dict[str, Any]]:
        """
        Retrieve relevant document chunks for a given query.
        
        Args:
            query: User query
            k: Number of chunks to retrieve
            
        Returns:
            List of relevant document chunks
        """
        return self.vector_store.similarity_search(query, k=k)
    
    def retrieve_with_scores(self, query: str, k: int = 4) -> List[Tuple[Dict[str, Any], float]]:
        """
        Retrieve relevant document chunks with similarity scores.
        
        Args:
            query: User query
            k: Number of chunks to retrieve
            
        Returns:
            List of tuples (document chunk, similarity score)
        """
        return self.vector_store.similarity_search_with_score(query, k=k)
    
    def generate_response(self, query: str, k: int = 4) -> Dict[str, Any]:
        """
        Generate a response to a user query using retrieved documents.
        
        Args:
            query: User query
            k: Number of chunks to retrieve
            
        Returns:
            Dictionary containing response and source documents
        """
        # Retrieve relevant chunks
        chunks_with_scores = self.retrieve_with_scores(query, k=k)
        
        if not chunks_with_scores:
            return {
                "answer": "I couldn't find any relevant information to answer your question.",
                "sources": [],
                "source_chunks": []
            }
        
        # Extract chunks and scores
        chunks = [chunk for chunk, _ in chunks_with_scores]
        scores = [score for _, score in chunks_with_scores]
        
        # Simple response generation by concatenating relevant chunks
        # In a real system, this would use an LLM to generate a coherent response
        response = self._generate_simple_response(query, chunks, scores)
        
        # Extract source information
        sources = self._extract_sources(chunks)
        
        return {
            "answer": response,
            "sources": sources,
            "source_chunks": chunks
        }
    
    def _generate_simple_response(self, query: str, chunks: List[Dict[str, Any]], scores: List[float]) -> str:
        """
        Generate a simple response based on retrieved chunks.
        
        Args:
            query: User query
            chunks: Retrieved document chunks
            scores: Similarity scores for chunks
            
        Returns:
            Generated response
        """
        # For demonstration purposes, we'll use a template-based approach
        # In a real system, this would use an LLM to generate a coherent response
        
        if not chunks:
            return "I couldn't find any relevant information to answer your question."
        
        # Use the most relevant chunk as the primary response
        primary_chunk = chunks[0].page_content
        
        # Create a response using a template
        response = f"Based on the documents I've analyzed, here's what I found about '{query}':\n\n"
        response += primary_chunk
        
        # Add additional information from other chunks if they add value
        if len(chunks) > 1:
            response += "\n\nAdditional relevant information:\n\n"
            for i, chunk in enumerate(chunks[1:], 1):
                response += f"- {chunk.page_content[:200]}...\n\n"
        
        return response
    
    def _extract_sources(self, chunks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Extract source information from document chunks.
        
        Args:
            chunks: Retrieved document chunks
            
        Returns:
            List of source information dictionaries
        """
        sources = []
        seen_sources = set()
        
        for chunk in chunks:
            source = chunk.metadata.get("source", "Unknown")
            page = chunk.metadata.get("page", 1)
            
            # Create a unique identifier for the source+page combination
            source_id = f"{source}_{page}"
            
            if source_id not in seen_sources:
                sources.append({
                    "file": source,
                    "page": page,
                    "text": chunk.page_content[:100] + "..."  # Preview of content
                })
                seen_sources.add(source_id)
        
        return sources


if __name__ == "__main__":
    # Example usage
    rag_system = RAGQuerySystem()
    
    # Test queries
    test_queries = [
        "What is RAG?",
        "What are the components of a RAG system?",
        "How does chunking affect retrieval precision?",
        "What is answer verification in RAG systems?"
    ]
    
    for query in test_queries:
        print(f"\n\n=== Query: {query} ===\n")
        result = rag_system.generate_response(query, k=3)
        
        print("Answer:")
        print(result["answer"])
        
        print("\nSources:")
        for i, source in enumerate(result["sources"], 1):
            print(f"{i}. {source['file']} (Page {source['page']})")
