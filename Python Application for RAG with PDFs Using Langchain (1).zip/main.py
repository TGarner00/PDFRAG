"""
Main entry point for the PDF RAG Application

This module provides the main entry point for the PDF RAG application,
allowing users to start either the CLI or web interface.
"""

import argparse
import sys
from cli import CommandLineInterface
import os

def main():
    """Main entry point for the application."""
    parser = argparse.ArgumentParser(description='PDF RAG Application')
    parser.add_argument('--cli', action='store_true', help='Start command-line interface')
    parser.add_argument('--web', action='store_true', help='Start web interface')
    
    args = parser.parse_args()
    
    if args.cli:
        # Start command-line interface
        cli = CommandLineInterface()
        cli.run()
    elif args.web:
        # Start web interface using Streamlit
        try:
            import streamlit
            # Use os.system to run streamlit command
            os.system(f"{sys.executable} -m streamlit run web_interface.py")
        except ImportError:
            print("Error: Streamlit is not installed. Please install it with 'pip install streamlit'.")
            sys.exit(1)
    else:
        # If no arguments provided, show help
        parser.print_help()


if __name__ == "__main__":
    main()
