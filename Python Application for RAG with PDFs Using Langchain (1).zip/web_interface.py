"""
Web Interface for PDF RAG Application

This module implements a web interface for the PDF RAG application using Streamlit,
allowing users to interact with the system through a graphical user interface.
"""

import os
import streamlit as st
from typing import List, Dict, Any
from dotenv import load_dotenv

from pdf_processor import PDFProcessor
from lightweight_vector_store import LightweightVectorStore
from rag_query_system import RAGQuerySystem
from answer_verification import AnswerVerificationSystem
from additional_features import AdditionalFeatures

# Load environment variables
load_dotenv()

class WebInterface:
    """Web interface for the PDF RAG application using Streamlit."""
    
    def __init__(self):
        """Initialize the web interface components."""
        self.pdf_processor = PDFProcessor()
        self.vector_store = LightweightVectorStore()
        self.rag_system = RAGQuerySystem(self.vector_store)
        self.verifier = AnswerVerificationSystem(self.rag_system)
        self.features = AdditionalFeatures(self.rag_system)
    
    def run(self):
        """Run the web interface."""
        st.set_page_config(
            page_title="PDF RAG Application",
            page_icon="📚",
            layout="wide"
        )
        
        st.title("PDF RAG Application")
        st.write("A system for RAG (Retrieval Augmented Generation) on PDFs with answer verification")
        
        # Sidebar for navigation
        st.sidebar.title("Navigation")
        page = st.sidebar.radio(
            "Select a page:",
            ["Home", "Query System", "Answer Verification", "Yes/No Verification", "Document Summarization", "Metadata Explorer"]
        )
        
        # Display the selected page
        if page == "Home":
            self._home_page()
        elif page == "Query System":
            self._query_page()
        elif page == "Answer Verification":
            self._verification_page()
        elif page == "Yes/No Verification":
            self._yes_no_verification_page()
        elif page == "Document Summarization":
            self._summarization_page()
        elif page == "Metadata Explorer":
            self._metadata_page()
    
    def _home_page(self):
        """Display the home page."""
        st.header("Welcome to the PDF RAG Application")
        
        st.subheader("Available Documents")
        pdf_files = self.pdf_processor.list_pdf_files()
        
        if not pdf_files:
            st.warning("No PDF documents found. Please add documents to the data directory.")
        else:
            st.write(f"Found {len(pdf_files)} PDF documents:")
            for pdf_file in pdf_files:
                st.write(f"- {os.path.basename(pdf_file)}")
        
        st.subheader("System Features")
        st.markdown("""
        This application provides the following features:
        
        - **Query System**: Ask questions about the content of your PDF documents
        - **Answer Verification**: Verify if an answer is supported by evidence in the documents
        - **Yes/No Verification**: Specialized verification for yes/no questions with logical deduction
        - **Document Summarization**: Generate summaries of your documents
        - **Metadata Explorer**: Explore metadata information from your documents
        
        Use the navigation sidebar to access these features.
        """)
    
    def _query_page(self):
        """Display the query page."""
        st.header("Query System")
        st.write("Ask questions about the content of your PDF documents")
        
        # Input for question
        question = st.text_input("Enter your question:")
        k = st.slider("Number of chunks to retrieve:", min_value=1, max_value=10, value=4)
        
        if st.button("Submit Query"):
            if not question:
                st.error("Please enter a question.")
            else:
                with st.spinner("Generating answer..."):
                    result = self.features.answer_question(question, k=k)
                
                st.subheader("Answer")
                st.write(result["answer"])
                
                st.subheader("Sources")
                for i, source in enumerate(result["sources"], 1):
                    st.write(f"{i}. {source['file']} (Page {source['page']})")
                    st.write(f"   {source['text']}")
    
    def _verification_page(self):
        """Display the verification page."""
        st.header("Answer Verification")
        st.write("Verify if an answer is supported by evidence in the documents")
        
        # Input for question and answer
        question = st.text_input("Enter the question:")
        answer = st.text_area("Enter the answer to verify:")
        k = st.slider("Number of chunks to retrieve:", min_value=1, max_value=10, value=4)
        
        if st.button("Verify Answer"):
            if not question or not answer:
                st.error("Please enter both a question and an answer.")
            else:
                with st.spinner("Verifying answer..."):
                    result = self.verifier.verify_answer(question, answer, k=k)
                
                st.subheader("Verification Result")
                
                # Display verification status with color
                if result["verified"]:
                    st.success(f"✅ Verified with {result['confidence']:.1%} confidence")
                else:
                    st.error(f"❌ Not verified ({result['confidence']:.1%} confidence)")
                
                st.write(f"**Explanation**: {result['explanation']}")
                
                if result["evidence"]:
                    st.subheader("Evidence")
                    for i, evidence in enumerate(result["evidence"], 1):
                        st.write(f"{i}. {evidence['source']} (Page {evidence['page']})")
                        st.write(f"   {evidence['text'][:300]}...")
    
    def _yes_no_verification_page(self):
        """Display the specialized yes/no verification page."""
        st.header("Yes/No Answer Verification")
        st.write("Verify yes/no answers with logical deduction based on evidence in the documents")
        
        # Input for question
        question = st.text_input("Enter a yes/no question:")
        
        # Radio buttons for yes/no answer
        answer = st.radio("Select your answer:", ["Yes", "No"])
        answer = answer.lower()  # Convert to lowercase for processing
        
        k = st.slider("Number of chunks to retrieve:", min_value=1, max_value=10, value=4)
        
        if st.button("Verify Yes/No Answer"):
            if not question:
                st.error("Please enter a question.")
            else:
                with st.spinner("Verifying answer..."):
                    # Verify the selected answer
                    result = self.verifier.verify_answer(question, answer, k=k)
                    
                    # Verify the opposite answer for comparison
                    opposite_answer = "no" if answer == "yes" else "yes"
                    opposite_result = self.verifier.verify_answer(question, opposite_answer, k=k)
                
                # Create columns for side-by-side comparison
                col1, col2 = st.columns(2)
                
                with col1:
                    st.subheader(f"Your Answer: {answer.upper()}")
                    
                    # Display verification status with color
                    if result["verified"]:
                        st.success(f"✅ Verified with {result['confidence']:.1%} confidence")
                    else:
                        st.error(f"❌ Not verified ({result['confidence']:.1%} confidence)")
                    
                    st.write(f"**Explanation**: {result['explanation']}")
                
                with col2:
                    st.subheader(f"Opposite Answer: {opposite_answer.upper()}")
                    
                    # Display verification status with color
                    if opposite_result["verified"]:
                        st.success(f"✅ Verified with {opposite_result['confidence']:.1%} confidence")
                    else:
                        st.error(f"❌ Not verified ({opposite_result['confidence']:.1%} confidence)")
                    
                    st.write(f"**Explanation**: {opposite_result['explanation']}")
                
                # Display evidence
                st.subheader("Evidence Analysis")
                
                if result["evidence"]:
                    st.write("Top evidence for your answer:")
                    for i, evidence in enumerate(result["evidence"][:3], 1):
                        with st.expander(f"Evidence {i} - {'Supports' if evidence['supports'] else 'Contradicts'} ({evidence['relevance']:.2f} relevance)"):
                            st.write(f"**Source**: {evidence['source']} (Page {evidence['page']})")
                            st.write(f"**Text**: {evidence['text']}")
                            st.write(f"**Relevance**: {evidence['relevance']:.2f}")
                            st.write(f"**Supports**: {'Yes' if evidence['supports'] else 'No'}")
                            st.write(f"**Contradicts**: {'Yes' if evidence['contradicts'] else 'No'}")
                
                # Display question analysis
                st.subheader("Question Analysis")
                
                # Get question type and concepts by calling the verifier's internal methods
                question_normalized = self.verifier._normalize_text(question)
                question_type = self.verifier._analyze_question_type(question_normalized)
                question_concepts = self.verifier._extract_question_concepts(question_normalized)
                
                st.write(f"**Question Type**: {question_type.capitalize()}")
                st.write(f"**Subject**: {question_concepts.get('subject', 'N/A')}")
                st.write(f"**Predicate**: {question_concepts.get('predicate', 'N/A')}")
                st.write(f"**Negated**: {'Yes' if question_concepts.get('is_negated', False) else 'No'}")
                st.write(f"**Key Entities**: {', '.join(question_concepts.get('key_entities', ['None']))}")
    
    def _summarization_page(self):
        """Display the summarization page."""
        st.header("Document Summarization")
        st.write("Generate summaries of your documents")
        
        # Get list of documents
        pdf_files = self.pdf_processor.list_pdf_files()
        pdf_names = ["All Documents"] + [os.path.basename(pdf) for pdf in pdf_files]
        
        # Document selection
        selected_doc = st.selectbox("Select a document to summarize:", pdf_names)
        
        if st.button("Generate Summary"):
            with st.spinner("Generating summary..."):
                if selected_doc == "All Documents":
                    result = self.features.summarize_document()
                else:
                    result = self.features.summarize_document(selected_doc)
                
                st.subheader("Summary")
                st.write(result["summary"])
                
                st.subheader("Sources")
                for source in result["sources"]:
                    st.write(f"- {source['file']} ({source['pages']} pages)")
    
    def _metadata_page(self):
        """Display the metadata page."""
        st.header("Metadata Explorer")
        st.write("Explore metadata information from your documents")
        
        if st.button("Analyze Metadata"):
            with st.spinner("Analyzing document metadata..."):
                result = self.features.explore_document_metadata()
                
                st.subheader("Metadata Analysis")
                st.text(result["analysis"])
                
                st.subheader("Documents")
                for doc in result["documents"]:
                    st.write(f"**{doc['file']}** ({doc['pages']} pages)")
                    st.json(doc["metadata"])


def main():
    """Main entry point for the web interface."""
    web_interface = WebInterface()
    web_interface.run()


if __name__ == "__main__":
    main()
