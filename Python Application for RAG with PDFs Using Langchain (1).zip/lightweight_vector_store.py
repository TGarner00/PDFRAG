"""
Lightweight Vector Store Module for RAG Application

This module implements a simplified embedding and vector storage solution
that works within memory constraints.
"""

import os
import json
import numpy as np
from typing import List, Dict, Any, Tuple
from pathlib import Path
from dotenv import load_dotenv
import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Load environment variables
load_dotenv()

class LightweightVectorStore:
    """
    A lightweight vector store implementation using TF-IDF instead of neural embeddings.
    This approach requires less memory and computational resources.
    """
    
    def __init__(self, persist_directory: str = None):
        """
        Initialize the lightweight vector store.
        
        Args:
            persist_directory: Directory to persist the vector store (defaults to env variable)
        """
        self.persist_directory = persist_directory or os.getenv("CHROMA_DB_DIR", "./chroma_db")
        self.vectorizer = TfidfVectorizer(lowercase=True, stop_words='english')
        self.documents = []
        self.document_vectors = None
        self.metadata = []
        
        # Create directory if it doesn't exist
        os.makedirs(self.persist_directory, exist_ok=True)
        
        # Load existing data if available
        self._load_if_exists()
    
    def _load_if_exists(self) -> None:
        """Load existing vector store data if available."""
        vectors_path = os.path.join(self.persist_directory, "vectors.pkl")
        docs_path = os.path.join(self.persist_directory, "documents.json")
        metadata_path = os.path.join(self.persist_directory, "metadata.json")
        vectorizer_path = os.path.join(self.persist_directory, "vectorizer.pkl")
        
        if (os.path.exists(vectors_path) and os.path.exists(docs_path) 
                and os.path.exists(metadata_path) and os.path.exists(vectorizer_path)):
            try:
                with open(vectors_path, 'rb') as f:
                    self.document_vectors = pickle.load(f)
                
                with open(docs_path, 'r') as f:
                    self.documents = json.load(f)
                
                with open(metadata_path, 'r') as f:
                    self.metadata = json.load(f)
                
                with open(vectorizer_path, 'rb') as f:
                    self.vectorizer = pickle.load(f)
            except Exception as e:
                print(f"Error loading vector store: {e}")
                # Initialize empty if loading fails
                self.documents = []
                self.document_vectors = None
                self.metadata = []
    
    def _save(self) -> None:
        """Save vector store data to disk."""
        vectors_path = os.path.join(self.persist_directory, "vectors.pkl")
        docs_path = os.path.join(self.persist_directory, "documents.json")
        metadata_path = os.path.join(self.persist_directory, "metadata.json")
        vectorizer_path = os.path.join(self.persist_directory, "vectorizer.pkl")
        
        with open(vectors_path, 'wb') as f:
            pickle.dump(self.document_vectors, f)
        
        with open(docs_path, 'w') as f:
            json.dump(self.documents, f)
        
        with open(metadata_path, 'w') as f:
            json.dump(self.metadata, f)
        
        with open(vectorizer_path, 'wb') as f:
            pickle.dump(self.vectorizer, f)
    
    def add_documents(self, documents: List[Dict[str, Any]]) -> None:
        """
        Add documents to the vector store.
        
        Args:
            documents: List of document chunks to add
        """
        # Extract text content and metadata
        doc_texts = [doc.page_content for doc in documents]
        doc_metadata = [doc.metadata for doc in documents]
        
        if not self.documents:
            # First-time initialization
            self.documents = doc_texts
            self.metadata = doc_metadata
            self.document_vectors = self.vectorizer.fit_transform(doc_texts)
        else:
            # Add to existing documents
            self.documents.extend(doc_texts)
            self.metadata.extend(doc_metadata)
            
            # Re-fit the vectorizer with all documents
            self.document_vectors = self.vectorizer.fit_transform(self.documents)
        
        # Save to disk
        self._save()
    
    def similarity_search(self, query: str, k: int = 4) -> List[Dict[str, Any]]:
        """
        Perform similarity search on the vector store.
        
        Args:
            query: Query string
            k: Number of results to return
            
        Returns:
            List of document chunks most similar to the query
        """
        if not self.documents:
            raise ValueError("Vector store is empty. Add documents first.")
        
        # Transform query using the same vectorizer
        query_vector = self.vectorizer.transform([query])
        
        # Calculate similarity scores
        similarity_scores = cosine_similarity(query_vector, self.document_vectors).flatten()
        
        # Get top k indices
        top_indices = similarity_scores.argsort()[-k:][::-1]
        
        # Create document objects for the results
        results = []
        for idx in top_indices:
            doc = type('Document', (), {})()
            doc.page_content = self.documents[idx]
            doc.metadata = self.metadata[idx]
            results.append(doc)
        
        return results
    
    def similarity_search_with_score(self, query: str, k: int = 4) -> List[Tuple[Dict[str, Any], float]]:
        """
        Perform similarity search on the vector store and return scores.
        
        Args:
            query: Query string
            k: Number of results to return
            
        Returns:
            List of tuples (document, score) most similar to the query
        """
        if not self.documents:
            raise ValueError("Vector store is empty. Add documents first.")
        
        # Transform query using the same vectorizer
        query_vector = self.vectorizer.transform([query])
        
        # Calculate similarity scores
        similarity_scores = cosine_similarity(query_vector, self.document_vectors).flatten()
        
        # Get top k indices
        top_indices = similarity_scores.argsort()[-k:][::-1]
        
        # Create document objects for the results with scores
        results = []
        for idx in top_indices:
            doc = type('Document', (), {})()
            doc.page_content = self.documents[idx]
            doc.metadata = self.metadata[idx]
            results.append((doc, float(similarity_scores[idx])))
        
        return results
    
    def get_collection_stats(self) -> Dict[str, Any]:
        """
        Get statistics about the vector store collection.
        
        Returns:
            Dictionary with collection statistics
        """
        if not self.documents:
            return {"count": 0, "status": "empty"}
        
        return {
            "count": len(self.documents),
            "status": "populated"
        }


if __name__ == "__main__":
    # Example usage
    from pdf_processor import PDFProcessor
    
    # Process PDFs
    processor = PDFProcessor()
    chunks = processor.process_all_documents()
    print(f"Created {len(chunks)} document chunks")
    
    # Store in vector database
    vector_store = LightweightVectorStore()
    vector_store.add_documents(chunks)
    
    # Get collection stats
    stats = vector_store.get_collection_stats()
    print(f"Vector store stats: {stats}")
    
    # Test similarity search
    if chunks:
        results = vector_store.similarity_search("What is RAG?", k=2)
        print("\nSimilarity search results for 'What is RAG?':")
        for i, doc in enumerate(results):
            print(f"\nResult {i+1}:")
            print(f"Content: {doc.page_content[:200]}...")
            print(f"Metadata: {doc.metadata}")
