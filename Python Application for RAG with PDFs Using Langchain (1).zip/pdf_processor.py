"""
PDF Processing Module for RAG Application

This module handles loading PDF files, extracting text, and chunking documents
for later embedding and retrieval.
"""

import os
from typing import List, Dict, Any
from pathlib import Path
from dotenv import load_dotenv
from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter

# Load environment variables
load_dotenv()

class PDFProcessor:
    """Class for processing PDF documents for RAG application."""
    
    def __init__(self, pdf_dir: str = None):
        """
        Initialize the PDF processor.
        
        Args:
            pdf_dir: Directory containing PDF files (defaults to env variable)
        """
        self.pdf_dir = pdf_dir or os.getenv("PDF_DIR", "./data")
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200,
            length_function=len,
        )
    
    def list_pdf_files(self) -> List[str]:
        """
        List all PDF files in the specified directory.
        
        Returns:
            List of PDF file paths
        """
        pdf_dir = Path(self.pdf_dir)
        return [str(f) for f in pdf_dir.glob("*.pdf")]
    
    def load_pdf(self, pdf_path: str) -> List[Dict[str, Any]]:
        """
        Load a single PDF file and extract its text content.
        
        Args:
            pdf_path: Path to the PDF file
            
        Returns:
            List of document pages with text content and metadata
        """
        loader = PyPDFLoader(pdf_path)
        pages = loader.load()
        
        # Add source filename to metadata
        for page in pages:
            page.metadata["source"] = os.path.basename(pdf_path)
            page.metadata["page"] = page.metadata.get("page", 0) + 1
            
        return pages
    
    def load_all_pdfs(self) -> List[Dict[str, Any]]:
        """
        Load all PDFs from the directory and extract their text content.
        
        Returns:
            List of document pages from all PDFs
        """
        all_pages = []
        pdf_files = self.list_pdf_files()
        
        for pdf_file in pdf_files:
            try:
                pages = self.load_pdf(pdf_file)
                all_pages.extend(pages)
            except Exception as e:
                print(f"Error loading {pdf_file}: {e}")
        
        return all_pages
    
    def chunk_documents(self, documents: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Split documents into smaller chunks for embedding.
        
        Args:
            documents: List of document pages
            
        Returns:
            List of document chunks
        """
        return self.text_splitter.split_documents(documents)
    
    def process_all_documents(self) -> List[Dict[str, Any]]:
        """
        Process all PDF documents: load, extract text, and chunk.
        
        Returns:
            List of processed document chunks ready for embedding
        """
        documents = self.load_all_pdfs()
        chunks = self.chunk_documents(documents)
        return chunks


if __name__ == "__main__":
    # Example usage
    processor = PDFProcessor()
    pdf_files = processor.list_pdf_files()
    print(f"Found {len(pdf_files)} PDF files")
    
    if pdf_files:
        # Process all documents
        chunks = processor.process_all_documents()
        print(f"Created {len(chunks)} document chunks")
